#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "schedinfo.h"   // PA4

struct cpu cpus[NCPU];

struct proc proc[NPROC];

struct proc *initproc;

int nextpid = 1;
struct spinlock pid_lock;

extern void forkret(void);
static void freeproc(struct proc *p);

extern char trampoline[]; // trampoline.S

// helps ensure that wakeups of wait()ing
// parents are not lost. helps obey the
// memory model when using p->parent.
// must be acquired before any p->lock.
struct spinlock wait_lock;

// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if (pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int)(p - proc));
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
  }
}

// initialize the proc table.
void
procinit(void)
{
  struct proc *p;

  initlock(&pid_lock, "nextpid");
  initlock(&wait_lock, "wait_lock");
  for (p = proc; p < &proc[NPROC]; p++) {
    initlock(&p->lock, "proc");
    p->state = UNUSED;
    p->kstack = KSTACK((int)(p - proc));
  }
}

// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
  int id = r_tp();
  return id;
}

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu *
mycpu(void)
{
  int id = cpuid();
  struct cpu *c = &cpus[id];
  return c;
}

// Return the current struct proc *, or zero if none.
struct proc *
myproc(void)
{
  push_off();
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
  pop_off();
  return p;
}

int
allocpid()
{
  int pid;

  acquire(&pid_lock);
  pid = nextpid;
  nextpid = nextpid + 1;
  release(&pid_lock);

  return pid;
}

// Look in the process table for an UNUSED proc.
// If found, initialize state required to run in the kernel,
// and return with p->lock held.
// If there are no free procs, or a memory allocation fails, return 0.
static struct proc *
allocproc(void)
{
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if (p->state == UNUSED) {
      goto found;
    } else {
      release(&p->lock);
    }
  }
  return 0;

found:
  p->pid = allocpid();
  p->state = USED;

  // ---- PA4: initialise scheduling state (p->lock is held by allocproc) ----
  p->nsched   = 0;
  p->rticks   = 0;
  p->lastcpu  = 0;
  p->slice    = 1;                    // Q2: default slice 1 => original round-robin behaviour
  p->used     = 0;
  p->ctime    = 0;
  p->ftime    = 0;
  p->firstcpu = 0;
  // Q4: default = *every possible* hart, NOT "the harts booted so far".
  // userinit() runs on hart 0 before the other harts boot, so a boot-time snapshot
  // would pin init (and, by inheritance, every process) to hart 0 forever.
  // The booted_harts mask is applied only when the mask is reported/validated.
  p->affinity = ALL_HARTS;
  p->prio     = PRIO_NORMAL;          // Q5: default priority

  // Allocate a trapframe page.
  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  // An empty user page table.
  p->pagetable = proc_pagetable(p);
  if (p->pagetable == 0) {
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  // Set up new context to start executing at forkret,
  // which returns to user space.
  memset(&p->context, 0, sizeof(p->context));
  p->context.ra = (uint64)forkret;
  p->context.sp = p->kstack + PGSIZE;

  return p;
}

// free a proc structure and the data hanging from it,
// including user pages.
// p->lock must be held.
static void
freeproc(struct proc *p)
{
  if (p->trapframe)
    kfree((void *)p->trapframe);
  p->trapframe = 0;
  if (p->pagetable)
    proc_freepagetable(p->pagetable, p->sz);
  p->pagetable = 0;
  p->sz = 0;
  p->pid = 0;
  p->name[0] = 0;
  p->chan = 0;
  p->killed = 0;
  p->xstate = 0;
  p->state = UNUSED;
}

// Create a user page table for a given process, with no user memory,
// but with trampoline and trapframe pages.
pagetable_t
proc_pagetable(struct proc *p)
{
  pagetable_t pagetable;

  // An empty page table.
  pagetable = uvmcreate();
  if (pagetable == 0)
    return 0;

  // map the trampoline code (for system call return)
  // at the highest user virtual address.
  // only the supervisor uses it, on the way
  // to/from user space, so not PTE_U.
  if (mappages(pagetable, TRAMPOLINE, PGSIZE, (uint64)trampoline,
               PTE_R | PTE_X) < 0) {
    uvmfree(pagetable, 0);
    return 0;
  }

  // map the trapframe page just below the trampoline page, for
  // trampoline.S.
  if (mappages(pagetable, TRAPFRAME, PGSIZE, (uint64)(p->trapframe),
               PTE_R | PTE_W) < 0) {
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    uvmfree(pagetable, 0);
    return 0;
  }

  return pagetable;
}

// Free a process's page table, and free the
// physical memory it refers to.
void
proc_freepagetable(pagetable_t pagetable, uint64 sz)
{
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
  uvmfree(pagetable, sz);
}

// Set up first user process.
void
userinit(void)
{
  struct proc *p;

  p = allocproc();
  initproc = p;

  p->cwd = namei("/");

  p->state = RUNNABLE;

  release(&p->lock);
}

// Grow or shrink user memory by n bytes.
// Return 0 on success, -1 on failure.
int
growproc(int n)
{
  uint64 sz;
  struct proc *p = myproc();

  sz = p->sz;
  if (n > 0) {
    if (sz + n > TRAPFRAME) {
      return -1;
    }
    if ((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
      return -1;
    }
  } else if (n < 0) {
    sz = uvmdealloc(p->pagetable, sz, sz + n);
  }
  p->sz = sz;
  return 0;
}

// Create a new process, copying the parent.
// Sets up child kernel stack to return as if from fork() system call.
int
kfork(void)
{
  int i, pid;
  struct proc *np;
  struct proc *p = myproc();

  // Allocate process.
  if ((np = allocproc()) == 0) {
    return -1;
  }

  // Copy user memory from parent to child.
  if (uvmcopy(p->pagetable, np->pagetable, p->sz) < 0) {
    freeproc(np);
    release(&np->lock);
    return -1;
  }
  np->sz = p->sz;

  // copy saved user registers.
  *(np->trapframe) = *(p->trapframe);

  // Cause fork to return 0 in the child.
  np->trapframe->a0 = 0;

  // increment reference counts on open file descriptors.
  for (i = 0; i < NOFILE; i++)
    if (p->ofile[i])
      np->ofile[i] = filedup(p->ofile[i]);
  np->cwd = idup(p->cwd);

  safestrcpy(np->name, p->name, sizeof(p->name));

  pid = np->pid;

  // Not RUNNABLE yet, so no other CPU touches np: drop its lock before taking the parent's
  // (constraint: hold at most ONE process lock at a time).
  release(&np->lock);

  // PA4: snapshot the parent's scheduling attributes while holding *its* lock.
  acquire(&p->lock);
  int pslice = p->slice;     // Q2: child inherits slice
  int paff   = p->affinity;  // Q4: child inherits affinity mask (raw mask, see allocproc)
  int pprio  = p->prio;      // Q5: child inherits priority
  release(&p->lock);

  acquire(&wait_lock);
  np->parent = p;
  release(&wait_lock);

  acquire(&np->lock);
  np->slice    = pslice;
  np->affinity = paff;
  np->prio     = pprio;
  // Q3: record the creation time right where the child becomes RUNNABLE.
  // `ticks` is read without tickslock on purpose: clockintr() takes tickslock and then
  // p->lock (via wakeup), so taking tickslock while holding np->lock could deadlock.
  // An aligned 32-bit read is atomic, and one tick of staleness is harmless.
  np->ctime = __atomic_load_n(&ticks, __ATOMIC_RELAXED);
  np->state = RUNNABLE;
  release(&np->lock);

  return pid;
}

// Pass p's abandoned children to init.
// Caller must hold wait_lock.
void
reparent(struct proc *p)
{
  struct proc *pp;

  for (pp = proc; pp < &proc[NPROC]; pp++) {
    if (pp->parent == p) {
      pp->parent = initproc;
      wakeup(initproc);
    }
  }
}

// Exit the current process.  Does not return.
// An exited process remains in the zombie state
// until its parent calls wait().
void
kexit(int status)
{
  struct proc *p = myproc();

  if (p == initproc)
    panic("init exiting");

  // Close all open files.
  for (int fd = 0; fd < NOFILE; fd++) {
    if (p->ofile[fd]) {
      struct file *f = p->ofile[fd];
      fileclose(f);
      p->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(p->cwd);
  end_op();
  p->cwd = 0;

  acquire(&wait_lock);

  // Give any children to init.
  reparent(p);

  // Parent might be sleeping in wait().
  wakeup(p->parent);

  acquire(&p->lock);

  p->xstate = status;
  p->state = ZOMBIE;

  release(&wait_lock);

  // Jump into the scheduler, never to return.
  sched();
  panic("zombie exit");
}

// Wait for a child process to exit and return its pid.
// Return -1 if this process has no children.
int
kwait(uint64 addr)
{
  struct proc *pp;
  int havekids, pid;
  struct proc *p = myproc();

  acquire(&wait_lock);

  for (;;) {
    // Scan through table looking for exited children.
    havekids = 0;
    for (pp = proc; pp < &proc[NPROC]; pp++) {
      if (pp->parent == p) {
        // make sure the child isn't still in exit() or swtch().
        acquire(&pp->lock);

        havekids = 1;
        if (pp->state == ZOMBIE) {
          // Found one.
          pid = pp->pid;
          if (addr != 0 &&
              copyout(p->pagetable, p->sz, addr, (char *)&pp->xstate,
                      sizeof(pp->xstate)) < 0) {
            release(&pp->lock);
            release(&wait_lock);
            return -1;
          }
          pp->parent = 0;
          freeproc(pp);
          release(&pp->lock);
          release(&wait_lock);
          return pid;
        }
        release(&pp->lock);
      }
    }

    // No point waiting if we don't have any children.
    if (!havekids || killed(p)) {
      release(&wait_lock);
      return -1;
    }

    // Wait for a child to exit.
    sleep_prepare(p); //DOC: wait-sleep
    release(&wait_lock);
    sleep();
    acquire(&wait_lock);
  }
}

// =====================================================================================
// PA4 scheduler support.  (Everything between here and the end of scheduler() replaces the
// original scheduler().)
// =====================================================================================

// Q4: bitmask of harts that have finished booting. Set from main() with
// __atomic_fetch_or(). Used to validate and report affinity masks.
int booted_harts;

// Q3: non-zero while forkwatch is on.
int forkwatch_on;

// Q5: global policy (POLICY_RR = original round-robin, POLICY_PRIO = strict priority).
int sched_policy = POLICY_RR;

// Q5: one round-robin cursor per priority level = table slot picked last at that level.
// Shared by all harts; accessed with relaxed atomics. A lost update only changes who is
// picked next among equals, it can never break correctness, so no extra lock is needed.
static int rr_cursor[3] = { -1, -1, -1 };

// Q4: may p run on hart `id`? Caller must hold p->lock.
static inline int
hart_allowed(struct proc *p, int id)
{
  return (p->affinity >> id) & 1;
}

// Q5: is there a RUNNABLE process with priority strictly better (smaller number) than
// `level` that is allowed on hart `id`?  Holds ONE process lock at a time (never nested),
// so two harts scanning in table order cannot deadlock.
static int
better_runnable(int level, int id)
{
  struct proc *p;
  for (p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    int better = p->state == RUNNABLE && p->prio < level && hart_allowed(p, id);
    release(&p->lock);
    if (better)
      return 1;
  }
  return 0;
}

// Q5: pick the next process for hart `id` under POLICY_PRIO.
// Returns with the winner's p->lock HELD and p->state == RUNNABLE, or 0 if nothing may run.
//   1. scan once (one lock at a time) to find the best priority level that has an
//      eligible process;
//   2. walk the table round-robin starting after rr_cursor[level]; lock each candidate and
//      RE-CHECK state, level and affinity under the lock (it may have changed since step 1);
//   3. if every candidate changed in the meantime, start over.
// Holding only the winner's lock on return matches what the original loop held at swtch().
static struct proc*
pick_prio(int id)
{
  struct proc *p;

  for (;;){
    int best = PRIO_LOW + 1;                       // "no level found yet"
    for (p = proc; p < &proc[NPROC] && best > PRIO_HIGH; p++){
      acquire(&p->lock);
      if (p->state == RUNNABLE && hart_allowed(p, id) && p->prio < best)
        best = p->prio;
      release(&p->lock);
    }
    if (best > PRIO_LOW)
      return 0;                                    // nothing runnable here

    int cur = __atomic_load_n(&rr_cursor[best], __ATOMIC_RELAXED);
    for (int k = 1; k <= NPROC; k++){
      int slot = (cur + k) % NPROC;                // cur may be -1: first slot tried is 0
      p = &proc[slot];
      acquire(&p->lock);
      if (p->state == RUNNABLE && p->prio == best && hart_allowed(p, id)){
        __atomic_store_n(&rr_cursor[best], slot, __ATOMIC_RELAXED);
        return p;                                  // lock stays held for the caller
      }
      release(&p->lock);
    }
    // The candidates vanished between the two scans: scan again.
  }
}

// Switch this hart to p. Caller holds p->lock (and nothing else); p is RUNNABLE.
// Q1: counts nsched / lastcpu.  Q2: starts a fresh slice.
static void
run_proc(struct cpu *c, struct proc *p, int id)
{
  // Switch to chosen process. It is the process's job to release its lock and then
  // reacquire it before jumping back to us.
  p->state   = RUNNING;
  p->nsched++;                // Q1
  p->lastcpu = id;            // Q1
  p->used    = 0;             // Q2: a new turn begins
  c->proc    = p;
  swtch(&c->context, &p->context);

  // Don't re-enable interrupts on release.
  mycpu()->intena = 0;

  // Process is done running for now. It should have changed its p->state before coming back.
  c->proc = 0;
}

// Per-CPU process scheduler.
// Each CPU calls scheduler() after setting itself up. Scheduler never returns.
void
scheduler(void)
{
  struct proc *p;
  struct cpu *c = mycpu();

  c->proc = 0;
  for (;;){
    // The most recent process to run may have had interrupts turned off; enable them to
    // avoid a deadlock if all processes are waiting. Then turn them back off to avoid a
    // possible race between an interrupt and wfi.
    intr_on();
    intr_off();

    int id = cpuid();          // safe: interrupts are off. The scheduler thread never migrates.
    int found = 0;

    if (__atomic_load_n(&sched_policy, __ATOMIC_RELAXED) == POLICY_PRIO){
      // ---- Q5: strict priority, round-robin inside a level ----
      p = pick_prio(id);
      if (p){
        run_proc(c, p, id);
        found = 1;
        release(&p->lock);
      }
    } else {
      // ---- original round-robin scan (+ Q4: skip processes not allowed on this hart) ----
      for (p = proc; p < &proc[NPROC]; p++){
        acquire(&p->lock);
        if (p->state == RUNNABLE && hart_allowed(p, id)){
          run_proc(c, p, id);
          found = 1;
        }
        release(&p->lock);
      }
    }

    if (found == 0){
      // nothing to run (or nothing this hart may run); stop until an interrupt.
      // wfi wakes at the next timer tick, so a process that becomes runnable is noticed.
      asm volatile("wfi");
    }
  }
}

// Switch to scheduler.  Must hold only p->lock
// and have changed proc->state. Saves and restores
// intena because intena is a property of this
// kernel thread, not this CPU. It should
// be proc->intena and proc->noff, but that would
// break in the few places where a lock is held but
// there's no process.
void
sched(void)
{
  int intena;
  struct proc *p = myproc();

  if (!holding(&p->lock))
    panic("sched p->lock");
  if (mycpu()->noff != 1)
    panic("sched locks");
  if (p->state == RUNNING)
    panic("sched RUNNING");
  if (intr_get())
    panic("sched interruptible");

  intena = mycpu()->intena;
  swtch(&p->context, &mycpu()->context);
  mycpu()->intena = intena;
}

// Give up the CPU for one scheduling round.
void
yield(void)
{
  struct proc *p = myproc();
  acquire(&p->lock);
  p->state = RUNNABLE;
  sched();
  release(&p->lock);
}

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();

  // ---- PA4 Q3: forkret() runs exactly once per process, the first time a scheduler
  // switches to it. The scheduler still holds p->lock (=> interrupts are off, so cpuid()
  // is safe and the values we record are consistent). ----
  p->ftime    = __atomic_load_n(&ticks, __ATOMIC_RELAXED);
  p->firstcpu = cpuid();
  int fpid  = p->pid;
  int fhart = p->firstcpu;
  int fwait = p->ftime - p->ctime;

  // Still holding p->lock from scheduler.
  release(&p->lock);

  // Q3 constraint: print only AFTER p->lock is released (printk takes its own lock).
  if (__atomic_load_n(&forkwatch_on, __ATOMIC_RELAXED))
    printk("pid %d: first run on hart %d, %d ticks after fork\n", fpid, fhart, fwait);

  if (first) {
    first = 0;

    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){"/init", 0});
    if (p->trapframe->a0 == -1) {
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
  uint64 satp = MAKE_SATP(p->pagetable);
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
  ((void (*)(uint64))trampoline_userret)(satp);
}

// Register current process as waiting for wakeups on chan.
void
sleep_prepare(void *chan)
{
  struct proc *p = myproc();

  acquire(&p->lock);
  if (chan == 0)
    panic("sleep_prepare: zero chan");
  p->chan = chan;
  release(&p->lock);
}

// Put the thread to sleep.  Assumes sleep_prepare() was called before.
// If the channel registered by sleep_prepare() has been woken up in
// the meantime, do not go to sleep, and instead return immediately.
void
sleep(void)
{
  struct proc *p = myproc();

  acquire(&p->lock);
  if (p->chan != 0) {
    p->state = SLEEPING;
    sched();
  }
  release(&p->lock);
}

// Wake up all processes sleeping on channel chan.
void
wakeup(void *chan)
{
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if (p->chan == chan) {
      // If the process is waiting for wakeups on this channel,
      // signal that the wakeup happened by clearing p->chan.
      p->chan = 0;

      // If this waiting process has gotten so far as to actually
      // go to sleep, also set it back to RUNNING.
      if (p->state == SLEEPING) {
        p->state = RUNNABLE;
      }
    }
    release(&p->lock);
  }
}

// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
  struct proc *p;

  if (pid == 0)
    return -1;

  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if (p->pid == pid) {
      p->killed = 1;
      if (p->state == SLEEPING) {
        // Wake process from sleep().
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return -1;
}

void
setkilled(struct proc *p)
{
  acquire(&p->lock);
  p->killed = 1;
  release(&p->lock);
}

int
killed(struct proc *p)
{
  int k;

  acquire(&p->lock);
  k = p->killed;
  release(&p->lock);
  return k;
}

// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
  struct proc *p = myproc();
  if (user_dst) {
    return copyout(p->pagetable, p->sz, dst, src, len);
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}

// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
  struct proc *p = myproc();
  if (user_src) {
    return copyin(p->pagetable, p->sz, dst, src, len);
  } else {
    memmove(dst, (char *)src, len);
    return 0;
  }
}

// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
  static char *states[] = {
    // clang-format off
    [UNUSED]    = "unused",
    [USED]      = "used",
    [SLEEPING]  = "sleep ",
    [RUNNABLE]  = "runble",
    [RUNNING]   = "run   ",
    [ZOMBIE]    = "zombie"
    // clang-format on
  };
  struct proc *p;
  char *state;

  printk("\n");
  for (p = proc; p < &proc[NPROC]; p++) {
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    printk("%d %s %s", p->pid, state, p->name);
    printk("\n");
  }
}

// =====================================================================================
// PA4: scheduling API used by the system calls in sysproc.c and by trap.c
// =====================================================================================

// Find a live process by pid and return it with p->lock HELD (0 if there is none).
// pid == 0 means "the calling process". Zombies count as live: they still have a pid.
// Only one lock is ever held at a time.
static struct proc*
lock_pid(int pid)
{
  struct proc *p;

  if (pid == 0){
    p = myproc();
    acquire(&p->lock);
    return p;
  }
  for (p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if (p->state != UNUSED && p->pid == pid)
      return p;
    release(&p->lock);
  }
  return 0;
}

// Q1: copy the scheduling statistics of `pid` into *si (a KERNEL buffer).
// The copy to user space is done by the caller AFTER p->lock is released, because copyout
// may fault/sleep and must never run while a process lock is held.
// Works on zombies. Returns 0, or -1 if no process has that pid.
int
proc_getinfo(int pid, struct schedinfo *si)
{
  struct proc *p;

  if (pid <= 0 || (p = lock_pid(pid)) == 0)
    return -1;
  si->pid      = p->pid;
  si->state    = p->state;          // enum procstate values == PS_* values (see schedinfo.h)
  si->nsched   = p->nsched;
  si->rticks   = p->rticks;
  si->lastcpu  = p->lastcpu;
  si->slice    = p->slice;
  si->ctime    = p->ctime;
  si->ftime    = p->ftime;
  si->firstcpu = p->firstcpu;
  // report only harts that really booted (the stored mask is the raw request)
  si->affinity = p->affinity & __atomic_load_n(&booted_harts, __ATOMIC_SEQ_CST);
  si->prio     = p->prio;
  safestrcpy(si->name, p->name, sizeof(si->name));   // Bonus
  release(&p->lock);
  return 0;
}

// Q2: set the time slice (in ticks) of `pid`; pid 0 = caller.
int
proc_setslice(int pid, int n)
{
  struct proc *p;

  if (n < 1 || n > 100)
    return -1;
  if ((p = lock_pid(pid)) == 0)
    return -1;
  p->slice = n;                       // written only under p->lock
  release(&p->lock);
  return 0;
}

// Q4: set the affinity mask of `pid`; pid 0 = caller.
int
proc_setaffinity(int pid, int mask)
{
  struct proc *p;
  int move = 0;

  // The mask must contain at least one hart that actually booted.
  if ((mask & __atomic_load_n(&booted_harts, __ATOMIC_SEQ_CST)) == 0)
    return -1;
  if ((p = lock_pid(pid)) == 0)
    return -1;

  p->affinity = mask & ALL_HARTS;     // drop bits for harts that cannot exist
  // If the caller removed the hart it is running on from its own mask it must move.
  // (cpuid() is safe here: holding p->lock keeps interrupts off.)
  if (p == myproc() && !hart_allowed(p, cpuid()))
    move = 1;
  release(&p->lock);

  // yield() takes p->lock itself, so it must be called after the release. The scheduler on
  // this hart will skip us, and another hart whose bit is set will pick us up.
  // For a process running on ANOTHER hart nothing is needed here: sched_tick() notices at
  // that hart's next timer interrupt (within one tick) and makes it yield.
  if (move)
    yield();
  return 0;
}

// Q4: return the affinity mask of `pid` (only booted harts), or -1 if no such pid.
int
proc_getaffinity(int pid)
{
  struct proc *p;
  int mask;

  if ((p = lock_pid(pid)) == 0)
    return -1;
  mask = p->affinity & __atomic_load_n(&booted_harts, __ATOMIC_SEQ_CST);
  release(&p->lock);
  return mask;
}

// Q5: set the priority of `pid`; pid 0 = caller.
int
proc_setprio(int pid, int prio)
{
  struct proc *p;
  int lowered_self = 0;

  if (prio < PRIO_HIGH || prio > PRIO_LOW)
    return -1;
  if ((p = lock_pid(pid)) == 0)
    return -1;
  lowered_self = (p == myproc() && prio > p->prio);   // larger number = lower priority
  p->prio = prio;
  release(&p->lock);

  // A process that lowers its OWN priority under PRIO must give way right now (inside
  // this system call), not at the next timer tick. yield() re-runs the scheduler on this
  // hart; if nobody better is waiting it simply picks us again.
  if (lowered_self && __atomic_load_n(&sched_policy, __ATOMIC_RELAXED) == POLICY_PRIO)
    yield();
  return 0;
}

// Q5: switch the global policy; returns the OLD policy. -1 just reads it.
// Any other value is rejected with -1 and changes nothing.
int
proc_setpolicy(int policy)
{
  if (policy == -1)
    return __atomic_load_n(&sched_policy, __ATOMIC_SEQ_CST);
  if (policy != POLICY_RR && policy != POLICY_PRIO)
    return -1;
  return __atomic_exchange_n(&sched_policy, policy, __ATOMIC_SEQ_CST);
}

// Q3: set forkwatch on/off; returns the previous setting (0 or 1).
int
proc_forkwatch(int on)
{
  return __atomic_exchange_n(&forkwatch_on, on != 0, __ATOMIC_SEQ_CST);
}

// Bonus: store up to `max` pids of non-UNUSED processes in buf (kernel memory); return count.
int
proc_getpids(int *buf, int max)
{
  struct proc *p;
  int n = 0;

  for (p = proc; p < &proc[NPROC] && n < max; p++){
    acquire(&p->lock);
    if (p->state != UNUSED)
      buf[n++] = p->pid;
    release(&p->lock);
  }
  return n;
}

// Called from usertrap() and kerneltrap() on EVERY timer interrupt that hits process p
// (p is RUNNING on this hart). Interrupts are off. Returns non-zero if p must yield now.
//   Q1: counts the interrupt in rticks.
//   Q2: counts one tick of the current slice; yield only when the slice is used up.
//   Q4: yield if this hart is no longer in p's mask (mask changed while p was running).
//   Q5: under PRIO, yield early if a strictly better process is waiting for this hart,
//       so a low-priority process with a long slice cannot delay a high-priority one.
int
sched_tick(struct proc *p)
{
  int yield_now = 0, id, prio;

  acquire(&p->lock);
  id = cpuid();                       // interrupts already off; lock held anyway
  p->rticks++;
  p->used++;
  if (p->used >= p->slice)
    yield_now = 1;
  if (!hart_allowed(p, id))
    yield_now = 1;
  prio = p->prio;
  release(&p->lock);                  // never scan the table with our own lock held

  if (!yield_now &&
     __atomic_load_n(&sched_policy, __ATOMIC_RELAXED) == POLICY_PRIO &&
     better_runnable(prio, id))
    yield_now = 1;
  return yield_now;
}
