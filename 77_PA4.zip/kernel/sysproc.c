#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "schedinfo.h"   // PA4
#include "vm.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  kexit(n);
  return 0; // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return kfork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return kwait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
  argint(1, &t);
  addr = myproc()->sz;

  if (t == SBRK_EAGER || n < 0) {
    if (growproc(n) < 0) {
      return -1;
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
      return -1;
    if (addr + n > TRAPFRAME)
      return -1;
    myproc()->sz += n;
  }
  return addr;
}

uint64
sys_pause(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  if (n < 0)
    n = 0;
  acquire(&tickslock);
  ticks0 = ticks;
  while (ticks - ticks0 < n) {
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep_prepare(&ticks);
    release(&tickslock);
    sleep();
    acquire(&tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kkill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

#include "procinfo.h"    // BONUS: struct procinfo shared with user/pstree.c

extern struct spinlock tickslock;   // defined in kernel/trap.c
extern uint ticks;                  // defined in kernel/trap.c
extern struct proc proc[NPROC];     // process table, defined in kernel/proc.c
extern struct spinlock wait_lock;   // defined in kernel/proc.c; protects every
                                    // p->parent pointer (see proc.c comments)

// Q1.
uint64 sys_getuptime (void) { //returns the number of timer ticks that have elapsed since the system booted.
  
  uint xticks; // holds local copy of number of ticks

  //`ticks` is incremented by clockintr() in trap.c while holding tickslock, so we read it under the SAME lock (assignment constraint).
  // accesses tick counter under its existing lock, samee as kernel
  acquire(&tickslock); //take same lock
  xticks = ticks; // we take copy
  release(&tickslock); // releases the lock before returning

  return xticks; //return value goes to syscall(), which writes this into trapframe->a0
}


// Q2.

uint64 sys_activecount(void) { //returns number of process-table entries whose state is not UNUSED
  
  struct proc *p; // cursor over the process table
  int count = 0; //stores total no of desired processes

  //iteration pattern same as scheduler() in proc.c
  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock); // taking p->lock before reading p->state as it is protected
    
    // checks for processes whose state is not UNUSED
    if(p->state != UNUSED) { //It is an read-only inspection, thus state is never modified
      count++;
    } 
    
    release(&p->lock); // lock is released on every iteration
  }

  return count;
}

// Q3.
uint64 sys_lineage(void) { // Prints pid/name of the proc and every ancestor up to init (pid 1) and return no of lines printed, or -1 if pid is not an active proc
  int pid;
  int pids[NPROC]; //ancestor pids collected
  char names[NPROC][PROCNAMELEN]; // collected ancestor names
  int n = 0; // stores no of entries collected
  int found = 0; //to check whetehr the starting PID was located or not
  struct proc *p;
  struct proc *next = 0; // pointer to the process to visit next

  argint(0, &pid); // fetches syscall argument 0 (a0)

  acquire(&wait_lock); //keeps chain stable(not a process lock)

  //locate the starting process
  for (p = proc; p < &proc[NPROC]; p++) {
    
    acquire(&p->lock);
    // slot matches only if pid is equal and slot is not UNUSED
    if (p->pid == pid && p->state != UNUSED) { 
      pids[n] = p->pid; //record pid
      safestrcpy(names[n], p->name, PROCNAMELEN);  //copy the name
      n++;
      next = p->parent; // remember who to visit next
      found = 1;
    }
    release(&p->lock); //lock is released before loop ends, regardless of match path or not
    
    if (found) {
      break;
    }
  }

  if (!found) { // pid doesn't exist
    release(&wait_lock); //release lock to prevent system from hanging
    return -1;
  }

  //walking up the ancestors
  while (next != 0 && pids[n-1] != 1 && n < NPROC) { //stop when no parent, the last process was not not init or we hit the safety cap
    
    struct proc *cur = next;
    acquire(&cur->lock); // lock the parent
    
    //if parent slot is free, stop and dont traverse
    if (cur->state == UNUSED) { // don't traverse through an unused entry
      release(&cur->lock);
      break;
    }

    //recording the ancestor
    pids[n] = cur->pid;
    safestrcpy(names[n], cur->name, PROCNAMELEN); //copy the name
    n++;
    next = cur->parent;// reading parent link while protected
    release(&cur->lock);// release lock before moving to the parent
  }

  release(&wait_lock); // all locking is released


  for (int i = 0; i < n; i++) {
    printk("PID %d: %s\n", pids[i], names[i]); //print from the private copies, with no locks held
  }
  return n; //no of lines printed
}


// Q4.
uint64 sys_getprocsize(void) { //given a pid, returns the total virtual mem size in bytes allocated to that proc (p->sz), or return -1 if the specified pid does not exist or corresponds to a proc in the UNUSED state
  
  int pid;
  struct proc *p;

  argint(0, &pid); //fetches syscall argument 0 (a0)

  for (p = proc; p < &proc[NPROC]; p++) {
    
    acquire(&p->lock); // holds at most one process lock at a time
    if (p->pid == pid && p->state != UNUSED) {
      uint64 sz = p->sz; //copy p->sz locally before releasing the lock
      release(&p->lock);
      return sz;
    }
    release(&p->lock);
  }
  return -1; // if no matches found, the pid doesnt exist or is UNUSED
}

// Q5.
uint64 sys_familyheadcount(void) { // returns the no of direct children the calling proc currently has that are still active (i.e., not yet reaped by wait())
  int unused_arg;
  struct proc *me = myproc(); //caller(proc that made system call)
  struct proc *p;
  int count = 0; //required no of count of direct children

  argint(0, &unused_arg); // parse (and ignore) the argument
  (void) unused_arg;

  
  acquire(&wait_lock); //hold while comparing parents
  for (p = proc; p < &proc[NPROC]; p++) {
    if (p->parent == me) { //match indicates p is a direct child
      acquire(&p->lock); //lock child to read its state safely 
      if (p->state != UNUSED && p->state != ZOMBIE) { //skips ZOMBIE & UNUSED as they are inactive
        count++;
      }
      release(&p->lock); //releasing child lock
    }
  }
  release(&wait_lock); 

  return count;
}

// Bonus Question.
uint64 sys_getprocs(void) {
  uint64 uaddr; // user-space addr of the buffer
  int max;
  struct proc *p;
  struct procinfo *buf;
  int n = 0;

  argaddr(0, &uaddr);               //a0: pointer into user mem = pointer(raw 64-bit addr)
  argint(1, &max);                  // a1: buffer capacity(no of entries)

  //validating input and capping it at the table size
  if (max <= 0) {
    return -1;
  }
  if (max > NPROC) {
    max = NPROC;
  }

  // 32 bytes * 64 entries = 2048 bytes <= PGSIZE, so one page is enough.
  buf = (struct procinfo *)kalloc(); //allocate one 4096-byte page using kalloc(), thus avoids overflowing the small(one page) kernal stack
  if (buf == 0) { //checks whether out of mem or not
    return -1;
  }

  acquire(&wait_lock); // makes p->parent stable for ppid below
  
  for (p = proc; p < &proc[NPROC] && n < max; p++) { 
    
    acquire(&p->lock);
    if (p->state != UNUSED) { //checks whether UNUSED or not
      buf[n].pid  = p->pid;
      buf[n].ppid = p->parent ? p->parent->pid : 0;  //ppid: parent pid, 0 for init(no parent)
      buf[n].sz   = p->sz;
      safestrcpy(buf[n].name, p->name, PROCNAMELEN); //copy the name
      n++;
    }
    release(&p->lock);
  }
  release(&wait_lock);

  // All locks are released here, thus copyout may be done safely.
    if (copyout(myproc()->pagetable, myproc()->sz, uaddr, (char *)buf,
              n * sizeof(struct procinfo)) < 0) {
    kfree(buf);
    return -1;
  }

  kfree(buf); //kfree the page(including on error) to avoid mem leaks
  return n; //return no of entries copied
}

// =====================================================================================
// PA4 system calls
// =====================================================================================

// Q1: id of the hart the caller is running on.
// cpuid() is only meaningful with interrupts off, hence push_off()/pop_off(). The value can
// be stale the moment we return (a timer interrupt may move the process), which is inherent.
uint64
sys_getcpu(void)
{
  int id;

  push_off();
  id = cpuid();
  pop_off();
  return id;
}

// Q1: int schedinfo(int pid, struct schedinfo *si)
uint64
sys_schedinfo(void)
{
  int pid;
  uint64 addr;
  struct schedinfo si;

  argint(0, &pid);
  argaddr(1, &addr);

  memset(&si, 0, sizeof(si));          // do not leak kernel stack bytes through padding
  if (proc_getinfo(pid, &si) < 0)       // fills si under p->lock, lock released on return
    return -1;
  // No process lock is held here, so copyout is allowed.
  if (copyout(myproc()->pagetable, myproc()->sz, addr, (char *)&si, sizeof(si)) < 0)
    return -1;
  return 0;
}

// Q2: int setslice(int pid, int n)
uint64
sys_setslice(void)
{
  int pid, n;

  argint(0, &pid);
  argint(1, &n);
  return proc_setslice(pid, n);
}

// Q3: int forkwatch(int on)
uint64
sys_forkwatch(void)
{
  int on;

  argint(0, &on);
  return proc_forkwatch(on);
}

// Q4: int sched_setaffinity(int pid, int mask)
uint64
sys_sched_setaffinity(void)
{
  int pid, mask;

  argint(0, &pid);
  argint(1, &mask);
  return proc_setaffinity(pid, mask);
}

// Q4: int sched_getaffinity(int pid)
uint64
sys_sched_getaffinity(void)
{
  int pid;

  argint(0, &pid);
  return proc_getaffinity(pid);
}

// Q5: int schedpolicy(int policy)
uint64
sys_schedpolicy(void)
{
  int policy;

  argint(0, &policy);
  return proc_setpolicy(policy);
}

// Q5: int setprio(int pid, int prio)
uint64
sys_setprio(void)
{
  int pid, prio;

  argint(0, &pid);
  argint(1, &prio);
  return proc_setprio(pid, prio);
}

// Bonus: int getpids(int *pids, int max)
uint64
sys_getpids(void)
{
  uint64 addr;
  int max, n;
  int tmp[NPROC];                      // 256 bytes of kernel stack; fine

  argaddr(0, &addr);
  argint(1, &max);
  if (max < 0)
    return -1;
  if (max > NPROC)
    max = NPROC;
  n = proc_getpids(tmp, max);
  if (n > 0 && copyout(myproc()->pagetable, myproc()->sz, addr, (char *)tmp,
             n * sizeof(int)) < 0)
    return -1;
  return n;
}
