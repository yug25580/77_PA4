// kernel/procinfo.h
// BONUS (pstree): a small, fixed-size "snapshot" of one process.

#ifndef _PROCINFO_H_
#define _PROCINFO_H_

#define PROCNAMELEN 16          // matches char name[16] in struct proc

struct procinfo {
  int    pid;                   // process id
  int    ppid;                  // parent's pid (0 for init, which has no parent)
  uint64 sz;                    // size of process memory in bytes (p->sz)
  char   name[PROCNAMELEN];     // process name (copied with safestrcpy)
};                              // sizeof == 32 bytes

#endif
