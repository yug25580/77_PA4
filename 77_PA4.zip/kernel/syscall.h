// System call numbers
#define SYS_fork   1
#define SYS_exit   2
#define SYS_wait   3
#define SYS_pipe   4
#define SYS_read   5
#define SYS_kill   6
#define SYS_exec   7
#define SYS_fstat  8
#define SYS_chdir  9
#define SYS_dup    10
#define SYS_getpid 11
#define SYS_sbrk   12
#define SYS_pause  13
#define SYS_uptime 14
#define SYS_open   15
#define SYS_write  16
#define SYS_mknod  17
#define SYS_unlink 18
#define SYS_link   19
#define SYS_mkdir  20
#define SYS_close  21
#define SYS_sync   22
//additional system calls

#define SYS_getuptime      23
#define SYS_activecount    24
#define SYS_lineage        25
#define SYS_getprocsize    26
#define SYS_familyheadcount 27
#define SYS_getprocs       28

// PA4
#define SYS_getcpu             29
#define SYS_schedinfo          30
#define SYS_setslice           31
#define SYS_forkwatch          32
#define SYS_sched_setaffinity  33
#define SYS_sched_getaffinity  34
#define SYS_schedpolicy        35
#define SYS_setprio            36
#define SYS_getpids            37
