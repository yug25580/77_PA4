// Bonus: xtop - a live, top-style process monitor for xv6.
//
//   xtop            redraw every 10 ticks until killed
//   xtop -d N       redraw every N ticks
//   xtop -n F       stop after F frames
//
// Built ONLY on system calls (getpids, schedinfo, schedpolicy, sched_getaffinity,
// uptime, pause): user space cannot read kernel memory.
//
// Notes on xv6 user space that shape this file:
//   * xv6's printf() has no width/precision (%5d, %-16s ...), so columns are padded by hand.
//   * the user stack is ONE page, so the big arrays below are static (they live in .bss).
//   * a process can exit between getpids() and schedinfo(); such pids are skipped.

#include "kernel/types.h"
#include "kernel/param.h"
#include "kernel/schedinfo.h"
#include "user/user.h"

#define MAXP  NPROC          // getpids() never returns more than NPROC pids
#define MAXH  16             // more harts than any xv6 build has (NCPU is 8)

// ---- snapshot storage (static: see note above) ----
static int pids[MAXP];
static struct schedinfo cur[MAXP];     // current sample, cur[0..ncur)
static int pct[MAXP];                  // %CPU of cur[i]
static int order[MAXP];                // indices of cur[], sorted by %CPU
static int prev_pid[MAXP];             // previous sample: pid -> rticks
static int prev_rt[MAXP];
static int nprev;

// ---------------------------------------------------------------- formatting helpers

// Write the decimal (base 10) or hex (base 16) form of v into buf; return the length.
static int
itoa_buf(char *buf, int v, int base)
{
  char tmp[16];
  int n = 0, len = 0;
  unsigned u = v < 0 ? -(unsigned)v : (unsigned)v;

  do {
    tmp[n++] = "0123456789abcdef"[u % base];
    u /= base;
  } while(u);
  if(v < 0)
    buf[len++] = '-';
  while(n)
    buf[len++] = tmp[--n];
  buf[len] = 0;
  return len;
}

static void
spaces(int n)
{
  while(n-- > 0)
    printf(" ");
}

// Print s left-aligned in a field of width w (never truncates a longer string).
static void
pl(char *s, int w)
{
  printf("%s", s);
  spaces(w - (int)strlen(s));
}

// Print s right-aligned in a field of width w.
static void
pr(char *s, int w)
{
  spaces(w - (int)strlen(s));
  printf("%s", s);
}

// Right-align the decimal number v in width w.
static void
pri(int v, int w)
{
  char b[16];
  itoa_buf(b, v, 10);
  pr(b, w);
}

// Print a mask as 0x<hex>, right-aligned in width w.
static void
prmask(int m, int w)
{
  char b[20] = "0x";
  itoa_buf(b + 2, m, 16);
  pr(b, w);
}

static char *
statename(int s)
{
  switch(s){
  case PS_USED:     return "used";
  case PS_SLEEPING: return "sleep";
  case PS_RUNNABLE: return "runble";
  case PS_RUNNING:  return "run";
  case PS_ZOMBIE:   return "zombie";
  }
  return "???";
}

// ---------------------------------------------------------------- sampling

// Fill cur[] from the kernel. Returns the number of processes sampled.
static int
sample(void)
{
  int n = getpids(pids, MAXP);
  int k = 0;

  for(int i = 0; i < n; i++){
    // The process may have exited since getpids(): schedinfo() then fails -> skip it.
    if(schedinfo(pids[i], &cur[k]) == 0)
      k++;
  }
  return k;
}

// rticks of `pid` in the previous sample, or 0 if the process is new.
static int
prev_rticks(int pid)
{
  for(int i = 0; i < nprev; i++)
    if(prev_pid[i] == pid)
      return prev_rt[i];
  return 0;
}

// Remember the current sample as the baseline for the next frame.
static void
save_prev(int n)
{
  for(int i = 0; i < n; i++){
    prev_pid[i] = cur[i].pid;
    prev_rt[i]  = cur[i].rticks;
  }
  nprev = n;
}

// Number of harts: the highest bit set in init's affinity mask (init keeps the default
// "every booted hart" mask unless somebody re-pins it). Fall back to what we have seen.
static int
count_harts(int n)
{
  int m = sched_getaffinity(1), h = 0;

  for(int b = 0; b < MAXH; b++)
    if(m & (1 << b))
      h = b + 1;
  for(int i = 0; i < n; i++)
    if(cur[i].lastcpu + 1 > h)
      h = cur[i].lastcpu + 1;
  return h > 0 ? h : 1;
}

// ---------------------------------------------------------------- one frame

// Draw one frame. `dt` = ticks since the previous sample (>= 1).
static void
draw(int n, int dt)
{
  int hartbusy[MAXH];
  int nh = count_harts(n);
  int self = getpid();
  int runnable = 0;

  for(int h = 0; h < MAXH; h++)
    hartbusy[h] = 0;

  for(int i = 0; i < n; i++){
    // %CPU = change in rticks since the last frame / interval
    int d = cur[i].rticks - prev_rticks(cur[i].pid);
    int p = d * 100 / dt;
    if(p > 100) p = 100;               // new processes are measured since their birth
    if(p < 0) p = 0;
    pct[i] = p;

    // "runnable" = ready or running, excluding ourselves (the observer).
    if(cur[i].pid != self &&
       (cur[i].state == PS_RUNNABLE || cur[i].state == PS_RUNNING))
      runnable++;

    // Approximate hart load: charge each process's CPU share to the hart it last ran on.
    if(cur[i].lastcpu >= 0 && cur[i].lastcpu < MAXH)
      hartbusy[cur[i].lastcpu] += p;
  }

  // sort indices by %CPU descending (insertion sort; ties keep table order)
  for(int i = 0; i < n; i++)
    order[i] = i;
  for(int i = 1; i < n; i++){
    int key = order[i], j = i - 1;
    while(j >= 0 && pct[order[j]] < pct[key]){
      order[j+1] = order[j];
      j--;
    }
    order[j+1] = key;
  }

  // ---- header ----
  printf("\x1b[H\x1b[2J");               // cursor home + clear screen
  printf("xtop up %d ticks procs %d runnable %d", uptime(), n, runnable);
  spaces(8);
  int pol = schedpolicy(-1);
  printf("policy %s\n", pol == POLICY_PRIO ? "PRIO" : "RR");
  for(int h = 0; h < nh; h++){
    int b = hartbusy[h] > 100 ? 100 : hartbusy[h];
    printf("hart%d %d%%  ", h, b);
  }
  printf("\n\n");

  // ---- table ----
  pr("PID", 5);   spaces(1);
  pl("NAME", 16); spaces(1);
  pl("STATE", 7); spaces(1);
  pr("PRIO", 4);  spaces(1);
  pr("CPU", 3);   spaces(1);
  pr("MASK", 6);  spaces(1);
  pr("SLICE", 5); spaces(1);
  pr("%CPU", 5);
  printf("\n");
  for(int r = 0; r < n; r++){
    struct schedinfo *s = &cur[order[r]];
    pri(s->pid, 5);        spaces(1);
    pl(s->name, 16);       spaces(1);
    pl(statename(s->state), 7); spaces(1);
    pri(s->prio, 4);       spaces(1);
    pri(s->lastcpu, 3);    spaces(1);
    prmask(s->affinity, 6); spaces(1);
    pri(s->slice, 5);      spaces(1);
    pri(pct[order[r]], 5);
    printf("\n");
  }
}

// ---------------------------------------------------------------- main

static void
usage(void)
{
  fprintf(2, "usage: xtop [-d ticks] [-n frames]\n");
  exit(1);
}

int
main(int argc, char *argv[])
{
  int delay = 10;        // -d N : ticks between frames
  int frames = -1;       // -n F : number of frames (-1 = until killed)

  for(int i = 1; i < argc; i++){
    if(strcmp(argv[i], "-d") == 0 && i + 1 < argc){
      delay = atoi(argv[++i]);
      if(delay < 1)
        usage();
    } else if(strcmp(argv[i], "-n") == 0 && i + 1 < argc){
      frames = atoi(argv[++i]);
      if(frames < 1)
        usage();
    } else {
      usage();
    }
  }

  // Baseline sample: %CPU needs two samples, so the first frame is drawn one interval
  // after the baseline. That is why `xtop -n 1` already shows meaningful percentages.
  int n = sample();
  save_prev(n);
  int last = uptime();

  for(int f = 0; frames < 0 || f < frames; f++){
    pause(delay);
    n = sample();
    int now = uptime();
    int dt = now - last;
    if(dt < 1)
      dt = 1;
    draw(n, dt);
    save_prev(n);
    last = now;
  }
  exit(0);
}
