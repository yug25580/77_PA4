// user/pstree.c
//BONUS: process tree visualiser.

#include "kernel/types.h" //gives types xv6 uses
#include "kernel/stat.h" 
#include "kernel/param.h" //gives constraints that size kernel's table(i.e. NPROC)
#include "kernel/procinfo.h" //struct defined for bonus: struct procinfo (shared with the kernel)
#include "user/user.h" //declares user-side lib: printf, fprintf, exit, and our new getprocs

static struct procinfo procs[NPROC];   //array that will receive snapshot from kernel with 2KB room(64 processes)
static int nprocs;                     // no of entries kernel actually fills in
static int show_pid = 0;               // -p sets show_pid(prints name only)
static int show_mem = 0;               // -m sets show_mem(prints name only)

static void usage (void) { //called when user types an invalid flag
  fprintf(2, "usage: pstree [-p] [-m]\n"); //writes std err to fd 2, so it is separate from normal o/p
  exit(1); //ends prog with non-zero status, meaning "failure"
}


static void print_node (struct procinfo *p) { //prints one process node on one line: name, optional (pid), optional [size]
  printf("%s", p->name); //prints process name
  if (show_pid) { //if -p was given, appends pid in (), giving init(1)
    printf("(%d)", p->pid);
  }
  if (show_mem) { //if -m was given, appends mem size in []
    printf(" [%dB]", (int)p->sz);
  }
  printf("\n");
}

static void walk (int pid, int depth) { //print every child of proc pid, and under each child print its children, and so on
  if (depth > NPROC) {                    // safety cap: tree cant be deeper than no of processes
    return;
  }

  for (int i = 0; i < nprocs; i++) { //scans whole snapshot looking for children of pid
    if (procs[i].ppid == pid && procs[i].pid != pid) { //if process's parent is the one and the proc is not its own parent
      for (int j = 1; j < depth; j++) {   // indentation
        printf("   ");
      }
      printf("|- "); //marks branch
      print_node(&procs[i]);
      walk(procs[i].pid, depth + 1);   // grandchildren, etc.
    }
  }
}

int main (int argc, char *argv[]) {
  // parsing flags
  for (int i = 1; i < argc; i++) {
    if (argv[i][0] != '-' || argv[i][1] == '\0') {
      usage();
    }
    for (char *c = argv[i] + 1; *c; c++) {
      if (*c == 'p') {
        show_pid = 1;
      } else if (*c == 'm') {
        show_mem = 1;
      } else {
        usage();
      }
    }
  }

  //getting data from kernel
  nprocs = getprocs(procs, NPROC); 
  if (nprocs < 0) { //-ve result means call failed, so we report on stderr and exit
    fprintf(2, "pstree: getprocs failed\n");
    exit(1);
  }

  //finding the root and printing
  for (int i = 0; i < nprocs; i++) {
    if (procs[i].pid == 1) { //search for init
      print_node(&procs[i]); //prints root line(init, init(1), ...)
      walk(1, 1); //prints entire tree below init
      exit(0); //0 status suggests success
    }
  }

  fprintf(2, "pstree: init not found\n"); // error if init doesnt exists
  exit(1);
}
